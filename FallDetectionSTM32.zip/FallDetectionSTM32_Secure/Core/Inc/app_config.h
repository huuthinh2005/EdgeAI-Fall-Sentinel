#ifndef APP_CONFIG_H
#define APP_CONFIG_H

/*
 * Safe repository defaults.
 *
 * For a private deployment, copy app_config_private.h.example to
 * app_config_private.h. That private file is ignored by Git and is loaded
 * automatically by GCC/Clang-compatible preprocessors.
 */
#if defined(__has_include)
#  if __has_include("app_config_private.h")
#    include "app_config_private.h"
#  endif
#endif

#ifndef APP_DEVICE_ID
#define APP_DEVICE_ID                   "CHANGE_ME"
#endif
#ifndef APP_MQTT_HOST
#define APP_MQTT_HOST                   ""
#endif
#ifndef APP_MQTT_PORT
#define APP_MQTT_PORT                   1883U
#endif
#ifndef APP_MQTT_USERNAME
#define APP_MQTT_USERNAME               ""
#endif
#ifndef APP_MQTT_PASSWORD
#define APP_MQTT_PASSWORD               ""
#endif
#ifndef APP_DEFAULT_EMERGENCY_PHONE
#define APP_DEFAULT_EMERGENCY_PHONE     ""
#endif

/* Topics are device-scoped to reduce accidental cross-device collisions. */
#ifndef APP_MQTT_TOPIC_TELEMETRY
#define APP_MQTT_TOPIC_TELEMETRY        "fall_detection/" APP_DEVICE_ID "/telemetry"
#endif
#ifndef APP_MQTT_TOPIC_ALARM
#define APP_MQTT_TOPIC_ALARM            "fall_detection/" APP_DEVICE_ID "/alarm"
#endif
#ifndef APP_MQTT_TOPIC_CONFIG
#define APP_MQTT_TOPIC_CONFIG           "fall_detection/" APP_DEVICE_ID "/config"
#endif

/*
 * The current SIM7680C connection sequence is plaintext TCP. It is disabled
 * in the repository build so GPS and alarm data cannot leak accidentally.
 * Set to 1 only for an isolated prototype test. A production build requires a
 * private broker, certificate-validated TLS, authentication, and topic ACLs.
 */
#ifndef APP_ENABLE_PLAINTEXT_MQTT
#define APP_ENABLE_PLAINTEXT_MQTT       0U
#endif

/* Never accept a phone number from an unauthenticated/shared broker. */
#ifndef APP_ALLOW_REMOTE_PHONE_CONFIG
#define APP_ALLOW_REMOTE_PHONE_CONFIG   0U
#endif

#if APP_ALLOW_REMOTE_PHONE_CONFIG && !APP_ENABLE_PLAINTEXT_MQTT
#error "Remote phone configuration requires an explicitly enabled MQTT transport"
#endif

#endif /* APP_CONFIG_H */
