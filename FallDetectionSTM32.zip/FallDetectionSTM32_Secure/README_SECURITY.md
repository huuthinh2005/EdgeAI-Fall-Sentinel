# STM32 firmware security and repository notes

## Removed from the public source

- The real emergency phone number is no longer compiled as a fallback.
- Broker settings and device-scoped topics are centralized in
  `Core/Inc/app_config.h`.
- Remote phone configuration is disabled by default while the firmware uses an
  unauthenticated public MQTT broker.
- Plaintext MQTT publishing is disabled by default, preventing accidental GPS
  disclosure from a repository build.
- Debug binaries and local IDE launch files are excluded from this package.

## Private configuration

Copy `Core/Inc/app_config_private.h.example` to
`Core/Inc/app_config_private.h` and add deployment-specific values. The copied
file is ignored by Git. Do not place a real phone number, password, certificate
private key, or token in a committed header.

`APP_ENABLE_PLAINTEXT_MQTT=1` exists only to reproduce an isolated prototype
test. It is not a production-security setting. `APP_ALLOW_REMOTE_PHONE_CONFIG`
must remain `0` on a shared or unauthenticated broker.

The emergency number stored on Flash page 62 is plaintext at rest. Before
handing a previously programmed board to another person, mass-erase the MCU or
erase that page. For production, evaluate STM32 readout protection and a secure
commissioning/erase process; do not change option bytes without a tested
recovery procedure because an incorrect setting can lock the device.

## Flash reservation

`STM32F103C8TX_FLASH.ld` limits application Flash to 62 KB:

```ld
FLASH (rx) : ORIGIN = 0x08000000, LENGTH = 62K
```

The address range `0x0800F800` to `0x0800FFFF` is outside the application
region. The emergency phone configuration begins at `0x0800F800`.

Rebuild the final firmware and keep the generated `.map` file as evidence. The
highest load address must remain below `0x0800F800`.

## Transport-security limitation

The supplied SIM7680C code still contains only a plaintext MQTT implementation,
and that path is disabled by default. The exact TLS AT-command profile and
certificate-provisioning procedure were not supplied, so no unverified modem
commands were invented. Do not transmit private GPS or phone information through
the public broker. Configure a private broker with certificate-validated TLS,
authentication, and per-device topic ACLs, then update the modem connection
sequence using the exact SIM7680C AT manual for the installed firmware version.

The EMQX public broker is for prototype testing only. Its topics are public even
when a client uses TLS.

## Build verification

This package changes the source, so any older `.map` file is not valid evidence
for this version. Rebuild the project, keep the new map file, then run:

```bash
python3 tools/verify_flash_map.py path/to/falldetection_real5.map
```
