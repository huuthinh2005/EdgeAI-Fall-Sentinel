#!/usr/bin/env python3
"""Verify that an STM32 linker map reserves the configuration Flash region."""

import re
import sys
from pathlib import Path

RESERVED_START = 0x0800F800


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: verify_flash_map.py <firmware.map>", file=sys.stderr)
        return 2

    text = Path(sys.argv[1]).read_text(errors="replace")
    memory = re.search(
        r"^FLASH\s+(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)",
        text,
        flags=re.MULTILINE,
    )
    if not memory:
        print("FAIL: FLASH memory definition was not found", file=sys.stderr)
        return 1

    origin = int(memory.group(1), 16)
    length = int(memory.group(2), 16)
    flash_end = origin + length
    if flash_end > RESERVED_START:
        print(
            f"FAIL: linker FLASH ends at 0x{flash_end:08X}, "
            f"overlapping reserved address 0x{RESERVED_START:08X}",
            file=sys.stderr,
        )
        return 1

    highest_loaded = origin
    highest_section = None
    section_pattern = re.compile(
        r"^(\.[^\s]+)\s+(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)"
        r"(?:\s+load address\s+(0x[0-9a-fA-F]+))?",
        flags=re.MULTILINE,
    )
    for match in section_pattern.finditer(text):
        name = match.group(1)
        if name in {".bss", ".noinit", "._user_heap_stack", ".heap", ".stack"}:
            continue
        virtual_address = int(match.group(2), 16)
        size = int(match.group(3), 16)
        load_address = int(match.group(4), 16) if match.group(4) else None
        address = load_address if load_address is not None else virtual_address
        if origin <= address < flash_end and size > 0:
            section_end = address + size
            if section_end > highest_loaded:
                highest_loaded = section_end
                highest_section = name

    if highest_loaded > RESERVED_START:
        print(
            f"FAIL: loaded section {highest_section} ends at "
            f"0x{highest_loaded:08X}, overlapping reserved address "
            f"0x{RESERVED_START:08X}",
            file=sys.stderr,
        )
        return 1

    if highest_section is None:
        print("FAIL: no loadable FLASH section was found", file=sys.stderr)
        return 1

    print(
        f"PASS: application FLASH is 0x{origin:08X}-0x{flash_end - 1:08X}; "
        f"highest loaded section ends at 0x{highest_loaded:08X}; "
        f"configuration starts at 0x{RESERVED_START:08X}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
