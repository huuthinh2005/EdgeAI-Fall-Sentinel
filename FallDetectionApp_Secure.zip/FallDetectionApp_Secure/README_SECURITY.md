# Fall Detection Android app — secure repository template

This package removes project-specific local files and makes privacy-sensitive
features fail closed. It is a secure starting point for source control, not a
claim that the complete prototype now provides end-to-end security.

## Before building

1. Copy `secrets.properties.example` to `secrets.properties` and replace every
   placeholder with values for your deployment.
2. Download a fresh `google-services.json` from your own Firebase project and
   place it in `app/google-services.json`.
3. Deploy `firestore.rules` and `database.rules.json` before allowing users to
   sign in.
4. Provision Realtime Database access with the Admin SDK or Firebase Console:

   ```text
   deviceAccess/<firebase-uid>/<device-id> = true
   ```

   Clients cannot grant this permission to themselves.

## Security changes

- MQTT, Firebase URL, device ID, and Google client ID are no longer hardcoded in
  Kotlin source.
- The Android MQTT client uses TLS by default (`MQTT_USE_TLS=true`, port 8883).
- MQTT topics are scoped as `fall_detection/<device-id>/...`.
- Remote emergency-phone configuration is disabled by default.
- The app does not retain or write the emergency phone number to Firebase.
- Incoming MQTT payloads are size-limited and field-validated before UI or
  database use.
- App broadcasts are explicitly restricted to this package.
- Cleartext network traffic and Android backup are disabled.
- Firebase rule examples default-deny and require explicit per-device access.
- Build outputs, local paths, Google service configuration, keystores, and
  private property files are excluded from Git.

## Important limits

- TLS to a public broker encrypts only the client-to-broker connection. It does
  not make public topics private. Use a private broker with authentication and
  per-device publish/subscribe ACLs for GPS or alarm data.
- MQTT credentials compiled into an APK can be extracted. Use narrow per-device
  privileges, rotation, revocation, and preferably short-lived credentials
  issued by a trusted backend.
- The supplied STM32 firmware does not yet implement verified TLS for the modem;
  its plaintext MQTT path is disabled in the secure repository build.
- Duplicate suppression and an optional timestamp check reduce accidental replay
  effects, but cryptographic anti-replay requires signed messages with a nonce or
  monotonic counter verified by the receiver.
- Firebase client-side role checks are not a security boundary. The included
  server-side rules must be deployed and tested with the Firebase Emulator.

## Files intentionally omitted

- `app/google-services.json`
- `secrets.properties` and `local.properties`
- `.gradle/`, `.idea/`, and all `build/` directories
- APK/AAB artifacts, signing keystores, certificates, and private keys
