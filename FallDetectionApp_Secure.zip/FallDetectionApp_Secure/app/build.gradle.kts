import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    id("com.google.gms.google-services")
}

val secrets = Properties().apply {
    val secretsFile = rootProject.file("secrets.properties")
    if (secretsFile.exists()) {
        secretsFile.inputStream().use(::load)
    }
}

fun configValue(name: String, defaultValue: String = ""): String =
    (secrets.getProperty(name) ?: System.getenv(name) ?: defaultValue).trim()

fun integerConfig(name: String, defaultValue: Int): String =
    (configValue(name).toIntOrNull()?.takeIf { it in 1..65535 } ?: defaultValue).toString()

fun booleanConfig(name: String, defaultValue: Boolean): String =
    configValue(name).toBooleanStrictOrNull()?.toString() ?: defaultValue.toString()

fun quotedBuildConfig(value: String): String =
    "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

android {
    namespace = "com.example.falldetectionapp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.falldetectionapp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        buildConfigField("String", "DEVICE_ID", quotedBuildConfig(configValue("DEVICE_ID")))
        buildConfigField("String", "MQTT_HOST", quotedBuildConfig(configValue("MQTT_HOST")))
        buildConfigField("int", "MQTT_PORT", integerConfig("MQTT_PORT", 8883))
        buildConfigField("boolean", "MQTT_USE_TLS", booleanConfig("MQTT_USE_TLS", true))
        buildConfigField("String", "MQTT_USERNAME", quotedBuildConfig(configValue("MQTT_USERNAME")))
        buildConfigField("String", "MQTT_PASSWORD", quotedBuildConfig(configValue("MQTT_PASSWORD")))
        buildConfigField(
            "boolean",
            "ALLOW_REMOTE_PHONE_CONFIG",
            booleanConfig("ALLOW_REMOTE_PHONE_CONFIG", false)
        )
        buildConfigField(
            "String",
            "FIREBASE_DATABASE_URL",
            quotedBuildConfig(configValue("FIREBASE_DATABASE_URL"))
        )
        buildConfigField(
            "String",
            "GOOGLE_SERVER_CLIENT_ID",
            quotedBuildConfig(configValue("GOOGLE_SERVER_CLIENT_ID"))
        )
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    // 👇 THÊM ĐOẠN NÀY (fix lỗi META-INF)
    packaging {
        resources {
            excludes += "META-INF/INDEX.LIST"
            excludes += "META-INF/io.netty.versions.properties" // 👈 thêm dòng này
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    // Thêm thư viện HiveMQ
    implementation("com.hivemq:hivemq-mqtt-client:1.3.3")
    implementation("com.google.firebase:firebase-database-ktx:20.3.1")
    // Google Maps
    implementation("com.google.android.gms:play-services-maps:18.2.0")
    implementation("com.google.android.gms:play-services-auth:21.2.0")

    // Credential Manager
    implementation("androidx.credentials:credentials:1.2.2")
    implementation("androidx.credentials:credentials-play-services-auth:1.2.2")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")

    // Firebase
    implementation(platform("com.google.firebase:firebase-bom:32.7.2"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}
