package com.example.falldetectionapp

object AppConfig {
    val deviceId: String = BuildConfig.DEVICE_ID.trim()
    val mqttHost: String = BuildConfig.MQTT_HOST.trim()
    val mqttPort: Int = BuildConfig.MQTT_PORT
    val mqttTopicTelemetry: String = "fall_detection/$deviceId/telemetry"
    val mqttTopicAlarm: String = "fall_detection/$deviceId/alarm"
    val mqttTopicConfig: String = "fall_detection/$deviceId/config"
    val firebaseDatabaseUrl: String = BuildConfig.FIREBASE_DATABASE_URL.trim()

    val isDeviceIdValid: Boolean
        get() = deviceId.matches(Regex("^[A-Za-z0-9_-]{1,32}$"))

    val isMqttConfigured: Boolean
        get() = mqttHost.isNotBlank() && mqttPort in 1..65535 && isDeviceIdValid

    val isFirebaseConfigured: Boolean
        get() = isDeviceIdValid && firebaseDatabaseUrl.startsWith("https://") &&
            !firebaseDatabaseUrl.contains("YOUR_PROJECT_ID")
}
