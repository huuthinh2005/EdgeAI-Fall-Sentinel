package com.example.falldetectionapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.datatypes.MqttQos
import com.hivemq.client.mqtt.mqtt3.Mqtt3AsyncClient
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.abs

class MqttService : Service() {

    companion object {
        const val ACTION_UPDATE = "com.example.falldetectionapp.MQTT_UPDATE"
        const val ACTION_PUBLISH_CONFIG = "PUBLISH_CONFIG"
        const val ACTION_STOP_ALARM = "STOP_ALARM_EFFECTS"
        const val EXTRA_TYPE = "type"
        const val EXTRA_DATA = "data"
        const val EXTRA_SUCCESS = "success"

        private const val MAX_PAYLOAD_BYTES = 1024
        private const val ALARM_DUPLICATE_WINDOW_MS = 30_000L
    }

    private lateinit var mqttClient: Mqtt3AsyncClient
    private val channelId = "fall_detection_service"
    private val alarmChannelId = "fall_alerts"
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private var lastAlarmPayload = ""
    private var lastAlarmReceivedAt = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        startForeground(100, createForegroundNotification())
        setupMqtt()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                channelId,
                "Fall Detection Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val alarmChannel = NotificationChannel(
                alarmChannelId,
                "Fall Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Thông báo khi phát hiện té ngã hoặc SOS"
                enableLights(true)
                lightColor = Color.RED
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java).apply {
                createNotificationChannel(serviceChannel)
                createNotificationChannel(alarmChannel)
            }
        }
    }

    private fun createForegroundNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Hệ thống bảo vệ đang chạy")
            .setContentText("Đang theo dõi trạng thái thiết bị...")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun setupMqtt() {
        if (!AppConfig.isMqttConfigured) {
            Log.e("MqttService", "MQTT configuration is missing or invalid")
            stopSelf()
            return
        }

        val builder = MqttClient.builder()
            .useMqttVersion3()
            .identifier("fall-app-${UUID.randomUUID()}")
            .serverHost(AppConfig.mqttHost)
            .serverPort(AppConfig.mqttPort)
            .automaticReconnectWithDefaultConfig()

        if (BuildConfig.MQTT_USE_TLS) {
            builder.sslWithDefaultConfig()
        }

        mqttClient = builder
            .addConnectedListener {
                Log.i("MqttService", "MQTT connected")
                subscribeToTopics()
            }
            .buildAsync()

        val connectBuilder = mqttClient.connectWith().cleanSession(true)
        if (BuildConfig.MQTT_USERNAME.isNotBlank()) {
            connectBuilder.simpleAuth()
                .username(BuildConfig.MQTT_USERNAME)
                .password(StandardCharsets.UTF_8.encode(BuildConfig.MQTT_PASSWORD))
                .applySimpleAuth()
        }
        connectBuilder.send().whenComplete { _, error ->
            if (error != null) {
                Log.e("MqttService", "MQTT connection failed", error)
            }
        }
    }

    private fun subscribeToTopics() {
        mqttClient.subscribeWith()
            .topicFilter(AppConfig.mqttTopicTelemetry)
            .qos(MqttQos.AT_LEAST_ONCE)
            .callback { publish -> decodePayload(publish.payloadAsBytes)?.let(::handleTelemetry) }
            .send()

        mqttClient.subscribeWith()
            .topicFilter(AppConfig.mqttTopicAlarm)
            .qos(MqttQos.AT_LEAST_ONCE)
            .callback { publish -> decodePayload(publish.payloadAsBytes)?.let(::handleAlarm) }
            .send()
    }

    private fun decodePayload(bytes: ByteArray): String? {
        if (bytes.isEmpty() || bytes.size > MAX_PAYLOAD_BYTES) {
            Log.w("MqttService", "Rejected MQTT payload with invalid size")
            return null
        }
        return bytes.toString(StandardCharsets.UTF_8)
    }

    private fun authenticatedDatabase(): DatabaseReference? {
        if (FirebaseAuth.getInstance().currentUser == null || !AppConfig.isFirebaseConfigured) {
            Log.w("MqttService", "Firebase write skipped: user or database is not configured")
            return null
        }
        return FirebaseDatabase.getInstance(AppConfig.firebaseDatabaseUrl).reference
    }

    private fun handleTelemetry(message: String) {
        try {
            val json = JSONObject(message)
            val lat = json.optDouble("lat", 0.0)
            val lon = json.optDouble("lon", 0.0)
            val battery = json.optInt("bat", -1)
            val status = json.optString("status", "UNKNOWN")
            val gpsStatus = json.optString("gps", "NONE").take(16)

            if (!validCoordinates(lat, lon) || status !in setOf("MOVING", "STILL", "UNKNOWN")) {
                Log.w("MqttService", "Rejected invalid telemetry payload")
                return
            }

            val telemetryData = mutableMapOf<String, Any>(
                "lat" to lat,
                "lon" to lon,
                "status" to status,
                "gps" to gpsStatus,
                "timestamp" to System.currentTimeMillis()
            )
            if (battery in 0..100) telemetryData["bat"] = battery

            authenticatedDatabase()
                ?.child("devices")
                ?.child(AppConfig.deviceId)
                ?.child("telemetry")
                ?.updateChildren(telemetryData)

            sendAppBroadcast("telemetry", JSONObject(telemetryData).toString())
        } catch (error: Exception) {
            Log.w("MqttService", "Rejected malformed telemetry", error)
        }
    }

    private fun handleAlarm(message: String) {
        val now = System.currentTimeMillis()
        if (message == lastAlarmPayload && now - lastAlarmReceivedAt < ALARM_DUPLICATE_WINDOW_MS) {
            return
        }

        val json = try {
            JSONObject(message)
        } catch (error: Exception) {
            Log.w("MqttService", "Rejected malformed alarm", error)
            return
        }

        val messageTimestamp = json.optLong("ts", 0L)
        val nowSeconds = now / 1000L
        if (messageTimestamp > 0L && abs(nowSeconds - messageTimestamp) > 300L) {
            Log.w("MqttService", "Rejected stale or future-dated alarm")
            return
        }

        val alert = json.optString("alert", "Cảnh báo khẩn cấp").take(80)
        val lat = json.optDouble("lat", 0.0)
        val lon = json.optDouble("lon", 0.0)
        val battery = json.optInt("bat", -1)
        val gpsStatus = json.optString("gps", "NONE").take(16)

        if (alert.isBlank() || !validCoordinates(lat, lon)) {
            Log.w("MqttService", "Rejected invalid alarm payload")
            return
        }

        lastAlarmPayload = message
        lastAlarmReceivedAt = now
        triggerAlarmEffects(alert)

        val database = authenticatedDatabase()
        val device = database?.child("devices")?.child(AppConfig.deviceId)
        val currentTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(now))
        val logData = mutableMapOf<String, Any>(
            "timestamp" to currentTime,
            "status" to alert,
            "lat" to lat,
            "lon" to lon,
            "gps" to gpsStatus
        )
        device?.child("logs")?.push()?.setValue(logData)
        device?.updateChildren(
            mapOf(
                "alert_status" to "ALARM",
                "last_alert_message" to alert
            )
        )

        val telemetryUpdate = mutableMapOf<String, Any>(
            "timestamp" to now,
            "gps" to gpsStatus
        )
        if (lat != 0.0 || lon != 0.0) {
            telemetryUpdate["lat"] = lat
            telemetryUpdate["lon"] = lon
        }
        if (battery in 0..100) telemetryUpdate["bat"] = battery
        device?.child("telemetry")?.updateChildren(telemetryUpdate)

        val sanitized = JSONObject().apply {
            put("alert", alert)
            put("lat", lat)
            put("lon", lon)
            put("bat", if (battery in 0..100) battery else -1)
            put("gps", gpsStatus)
        }
        sendAppBroadcast("alarm", sanitized.toString())
    }

    private fun validCoordinates(lat: Double, lon: Double): Boolean =
        lat.isFinite() && lon.isFinite() && lat in -90.0..90.0 && lon in -180.0..180.0

    private fun sendAppBroadcast(type: String, data: String, success: Boolean? = null) {
        val intent = Intent(ACTION_UPDATE)
            .setPackage(packageName)
            .putExtra(EXTRA_TYPE, type)
            .putExtra(EXTRA_DATA, data)
        success?.let { intent.putExtra(EXTRA_SUCCESS, it) }
        sendBroadcast(intent)
    }

    private fun publishPhoneConfig(phone: String) {
        if (!BuildConfig.ALLOW_REMOTE_PHONE_CONFIG) {
            sendAppBroadcast(
                "config_result",
                "Cấu hình số điện thoại từ xa đang bị khóa vì lý do bảo mật.",
                false
            )
            return
        }
        if (!phone.matches(Regex("^\\+?[0-9]{9,15}$"))) {
            sendAppBroadcast("config_result", "Số điện thoại không hợp lệ.", false)
            return
        }
        if (!::mqttClient.isInitialized || !mqttClient.state.isConnected) {
            sendAppBroadcast("config_result", "MQTT chưa kết nối; chưa gửi cấu hình.", false)
            return
        }

        mqttClient.publishWith()
            .topic(AppConfig.mqttTopicConfig)
            .qos(MqttQos.AT_LEAST_ONCE)
            .retain(false)
            .payload(phone.toByteArray(StandardCharsets.UTF_8))
            .send()
            .whenComplete { _, error ->
                if (error == null) {
                    sendAppBroadcast("config_result", "Đã gửi cấu hình đến broker.", true)
                } else {
                    Log.e("MqttService", "Phone configuration publish failed", error)
                    sendAppBroadcast("config_result", "Không gửi được cấu hình.", false)
                }
            }
    }

    private fun triggerAlarmEffects(message: String) {
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500), -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(longArrayOf(0, 500, 200, 500), -1)
        }

        val alarmUri: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        ringtone = RingtoneManager.getRingtone(applicationContext, alarmUri)
        ringtone?.play()
        Handler(Looper.getMainLooper()).postDelayed({ stopAlarmEffects() }, 15_000L)

        val openApp = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, alarmChannelId)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("CẢNH BÁO KHẨN CẤP")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(pendingIntent, true)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(1, notification)
    }

    private fun stopAlarmEffects() {
        ringtone?.takeIf { it.isPlaying }?.stop()
        vibrator?.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.getStringExtra("action")) {
            ACTION_PUBLISH_CONFIG -> publishPhoneConfig(intent?.getStringExtra("payload").orEmpty())
            ACTION_STOP_ALARM -> stopAlarmEffects()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopAlarmEffects()
        if (::mqttClient.isInitialized) mqttClient.disconnect()
        super.onDestroy()
    }
}
